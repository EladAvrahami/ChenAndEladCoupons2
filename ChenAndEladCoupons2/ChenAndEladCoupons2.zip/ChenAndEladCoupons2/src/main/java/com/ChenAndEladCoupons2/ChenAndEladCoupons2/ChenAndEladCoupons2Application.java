package com.ChenAndEladCoupons2.ChenAndEladCoupons2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChenAndEladCoupons2Application {

	public static void main(String[] args) {
		SpringApplication.run(ChenAndEladCoupons2Application.class, args);
	}

}
