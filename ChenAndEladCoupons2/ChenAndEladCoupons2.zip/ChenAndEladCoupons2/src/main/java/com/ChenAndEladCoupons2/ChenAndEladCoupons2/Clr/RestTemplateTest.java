//package com.ChenAndEladCoupons2.ChenAndEladCoupons2.Clr;
//
//
//import com.ChenAndEladCoupons2.ChenAndEladCoupons2.Beans.Company;
//import com.ChenAndEladCoupons2.ChenAndEladCoupons2.Beans.Customer;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.core.annotation.Order;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//import org.springframework.web.client.RestTemplate;
//
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@Component
//@Order(4)
//public class RestTemplateTest implements CommandLineRunner {
//    @Autowired
//    private RestTemplate restTemplate;
//
//    Customer chen = Customer
//            .builder ()
//            .firstName ("Chen")
//            .lastName ("Amos")
//            .email ("chen@chen.com")
//            .password ("xxxxx")
//            .build ();
//
//    Customer chen2 = Customer
//            .builder ()
//            .id (chen.getId ())
//            .firstName ("elados")
//            .lastName ("Avrahamos")
//            .email ("elados@chen.com")
//            .password ("non-sense")
//            .build ();
//
//
//    @Override
//    public void run(String... args) throws Exception {
////
//    }
//}
//
