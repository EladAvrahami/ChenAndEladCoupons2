package com.ChenAndEladCoupons2.ChenAndEladCoupons2.enums;
/**
 * An enum that describes all the types of clients
 */
public enum ClientType {
    admin, customer, company
}
