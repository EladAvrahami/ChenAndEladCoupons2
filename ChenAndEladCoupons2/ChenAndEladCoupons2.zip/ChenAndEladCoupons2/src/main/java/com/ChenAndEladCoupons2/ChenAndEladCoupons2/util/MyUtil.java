package com.ChenAndEladCoupons2.ChenAndEladCoupons2.util;

public class MyUtil {

    /**
     *this method add command that prints a line .
     */
    public static void printRow(){
        for (int counter=0;counter<100;counter+=1){
            System.out.print("=");
        }
        System.out.println();
    }


}
